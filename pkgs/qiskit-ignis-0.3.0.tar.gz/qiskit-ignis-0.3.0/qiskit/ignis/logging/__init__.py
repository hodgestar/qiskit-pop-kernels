"""
Ignis Logging package initialization
"""

from .ignis_logging import IgnisLogger, IgnisLogging, IgnisLogReader
